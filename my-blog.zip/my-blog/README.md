A simple landing program
